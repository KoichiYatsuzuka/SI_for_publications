# distutils: language=c++
# distutils: extra_compile_args = ["-O3"]

"""
# Common modules for electrochemical measurements.
There are the common things among Biologic, HokutoDenko, and so on.
For example, a class for voltammogram.

class list
    Potential [V]
    Current [A]
    Resistance [Ohm]

"""
from __future__ import annotations

import numpy as np
import pandas as pd
from copy import deepcopy as copy
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

from collections import namedtuple
from dataclasses import dataclass
from typing import Final, NewType, Optional, Union, TypeAlias, Self, overload, override
from enum import Enum

from .. import common as cmn
from .. import data_object as do
from ..quantity import ComplexQuantity, Quantity
from ..quantity_array import QArray

# distutils: language=c++
# distutils: extra_compile_args = ["-O3"]

#---------------------------------------------------------------
#Value object classes
#---------------------------------------------------------------


class Current(Quantity):
    """
    電流 [A]。実体 float のブランド付き物理量。
    note: iR correction can be performed via iR_correction()
    """
    def log10(self)->LogCurrent:
        """log10(|I|) を LogCurrent として返す。"""
        return LogCurrent(float(np.log10(np.abs(float(self)))))

    def iR_correction(self, registance: Resistance)->Potential:
        """iR 降下 (I x R) を Potential として返す。"""
        return Potential(float(self)*float(registance))


class CurrentC(ComplexQuantity):
    """複素電流。"""
    pass


class CurrentArray(QArray[Current]):
    """
    電流の配列。カスタムメソッドを持つため QArray[Current] のエイリアスでは
    なく継承クラス(電流配列はこのクラス名に統一して使うこと)。
    """
    def log10(self)->LogCurrentArray:
        """log10(|I|) の配列を返す。"""
        return LogCurrentArray(np.log10(np.abs(self.float_array())))

    def iR_correction(self, registance: Resistance)->PotentialArray:
        """iR 降下 (I x R) の配列を返す(ベクトル演算)。"""
        return PotentialArray(self.float_array()*float(registance))


CurrentCArray = QArray[CurrentC]


class Resistance(Quantity):
    """抵抗 [Ohm]。"""
    def to_impedance(self)->Impedance:
        return Impedance(float(self))


class ResistanceArray(QArray[Resistance]):
    """抵抗の配列。to_impedance を持つため継承クラス。"""
    def to_impedance(self)->ImpedanceArray:
        return ImpedanceArray(self.complex_array())


class Potential(Quantity):
    """
    電位 [V]。
    Potential / Current -> Resistance のオーム則除算を明示的に定義している
    (次元をまたぐ意味のある演算はサブクラスで個別に定義する方針)。
    """
    # Current は float のサブクラスなので overload の重複は原理的に避けられない
    # (意図的な特殊化のため抑制する)
    @overload
    def __truediv__(self, other: Current)->Resistance: ...  # pyright: ignore[reportOverlappingOverload]
    @overload
    def __truediv__(self, other: Quantity)->float: ...
    @overload
    def __truediv__(self, other: float)->Self: ...
    @overload
    def __truediv__(self, other: complex)->complex: ...
    @override
    def __truediv__(  # type: ignore[override]  # オーム則のための意図的な特殊化
        self, other: complex
    )->Resistance | Self | float | complex:
        if type(other) is Current:
            return Resistance(float(self) / float(other))
        return Quantity.__truediv__(self, other)


PotentialArray = QArray[Potential]


class LogCurrent(Quantity):
    """log10(電流)。値は無次元だがブランドを保持する。"""
    pass


LogCurrentArray = QArray[LogCurrent]


class Impedance(ComplexQuantity[Resistance]):
    """
    複素インピーダンス [Ohm]。
    real / imag / abs() は対の実数型 Resistance でラップされて返る。
    """
    _real_type = Resistance


ImpedanceArray = QArray[Impedance]


class Frequency(Quantity):
    """周波数 [Hz]。"""
    pass


FrequencyArray = QArray[Frequency]

#---------------------------------------------------------------
#Objects relating to potential
#---------------------------------------------------------------
ReferenceElectrode = Potential
"""
The type for conversion of potential.
Use ReferenceElectrodes enum or RHE() function.
"""

"""
*Only RHE is defined as a function.*
"""

SHE = ReferenceElectrode(0.0)
"""Standard Hydrogen Electrode"""
NHE = ReferenceElectrode(0.0)
"""Natural Hydrogen Electrode"""

SSCE = ReferenceElectrode(0.2)
"""
Ag/AgCl (Silver/Silver chloride electorde)
"""

def RHE(pH: float)->ReferenceElectrode:
    """ Retruens -0.059*pH
    """
    return ReferenceElectrode(-0.059*pH)

#---------------------------------------------------------------
#Value object classes
#---------------------------------------------------------------
@dataclass(frozen=True, repr=False)
class Voltammogram(do.DataSeriese[PotentialArray, CurrentArray]):
    """
    ## The dataclass to treat voltammograms
    Can be used for LSV and CV.\n
    This class is frozen, so you cannot re-write class members after initialization.\n
    If you want to adjust some things (like current to current density, or Ag/AgCl to SHE), use class methods.
    ### member values and properties
    potential: numpy.ndarray
    current: numpy.ndarray
    ### member methods
    """

    _potential: PotentialArray
    """in [V]"""
    @property
    def potential(self):
        return self._potential

    _current: CurrentArray
    """in [A]"""
    @property
    def current(self):
        return self._current
    
    _RE: Optional[ReferenceElectrode]
    @property
    def reference_electrode(self):
        return self._RE
    
    """_conditions: list[str]
    @property
    def conditions(self):
        return copy(self._conditions)"""
    
    _time: cmn.TimeArray
    @property
    def time(self):
        return self._time
    
    _others_data: pd.DataFrame

    @property
    def x(self):
        return self._potential
    
    @property
    def y(self):
        return self._current
    
    def to_data_frame(self):
        return pd.concat([
            pd.DataFrame(
                np.stack([
                    self._potential.float_array(),
                    self._current.float_array(),
                    self._time.float_array()
                ], 1),
                columns = [
                    "potential",
                    "current",
                    "time"
                ]
            ),
            self._others_data],
            axis=1
        )

    @property
    def Tafel_slope(self):
        """
        現在の仕様: 電流値を100 plot、4次関数でsavgol filterかけてから、∂E/∂log|I|のseriese作って返す。電流記録頻度によってfilterのかかる電位幅が変わる
        """
        #もし既に計算済みならそれを返す
        if "Tafel slope" in self._others_data.keys():
            return self._others_data["Tafel slope"]
        #計算したことないならそれを計算する
        len_array = len(self.current.log10())
        
        #電流値を平滑化
        current_tmp = savgol_filter(
            self.current.float_array(),
            100,
            4,
            deriv=0
            ) 

        #log iの計算
        logI_for = np.delete(np.log10(np.abs(current_tmp)), [0, 1, 2, 3, 4, 5])
        logI_back = np.delete(np.log10(np.abs(current_tmp)), [len_array-6, len_array-5, len_array-4, len_array-3, len_array-2, len_array-1])
        delta_logI = logI_for - logI_back
        
        # np.delete は QArray を素の ndarray に降格させるため、素の配列で計算する
        potential_raw = self.potential.float_array()
        E_for = np.delete(potential_raw, [0, 1, 2, 3, 4, 5])
        E_back = np.delete(potential_raw, [len_array-6, len_array-5, len_array-4, len_array-3, len_array-2, len_array-1])
        delta_E = E_for-E_back

        Tafel_slope_raw = delta_E*1000 / delta_logI

        tafel_slope_nparray = np.append(np.append([0, 0, 0], Tafel_slope_raw), [0, 0, 0])

        return copy(tafel_slope_nparray)

    @property
    def others_data(self):
        return self._others_data

    def __hash__(self) -> int:
        first_part_of_current = self.current[:10]
        hash_str = ""
        for current in first_part_of_current:
            tmp = str(current)
            tmp=tmp.replace(".", "")
            print(tmp)
            hash_str += tmp

        return int(hash_str)
    
    """def _data_finalize(original_obj, new_obj: Voltammogram)->Voltammogram:
        return new_obj"""
    
    """@cmn.immutator
    def __make_modified_object(self, modified_parameter: dict):
        new_obj = copy(self)

        all_dict = self.__dict__

        for par_key in all_dict.keys():
            if par_key in modified_parameter.keys():
                new_obj.__setattr__(par_key, modified_parameter[par_key])
            
        return new_obj"""

    
    @cmn.immutator
    def modify_voltammogram(
        self,
        new_potential: Optional[Potential] = None,
        new_current: Optional[Current] = None,
        new_time: Optional[cmn.Time] = None,
        new_others_data: Optional[np.ndarray] = None,
        prefix_to_data_name: Optional[str] = None
    ):
        tmp_prefix_candidate: str = "_"

        if new_potential == None:
            _new_potential = self._potential
        else:
            _new_potential = new_potential
            tmp_prefix_candidate = tmp_prefix_candidate + "potential_mod_"
            
        #match new_potential:
        #	case None:
        #		_new_potential = self._potential
        #	case _:
        #		_new_potential = new_potential
        #		tmp_prefix_candidate = tmp_prefix_candidate + "potential_mod_"
        
        if new_current == None:
            _new_current = self.current
        else:
            _new_current = new_current
            tmp_prefix_candidate = tmp_prefix_candidate + "current_mod_"
        
        #match new_current: 
        #	case None:
        #		_new_current = self.current
        #	case _:
        #		_new_current = new_current
        #		tmp_prefix_candidate = tmp_prefix_candidate + "current_mod_"
            
        if new_time == None:
            _new_time = self.time
        else:
            _new_time = new_time
        
        """match new_time:
            case None:
                _new_time = self.time
            case _:
                _new_time = new_time"""
        if new_others_data == None:
            _new_other_data = self.others_data
        else:
            _new_other_data = new_others_data
            tmp_prefix_candidate = tmp_prefix_candidate + "others_mod_"

        # match new_others_data:
        # 	case None:
        # 		_new_other_data = self.others_data
        # 	case _:
        # 		_new_other_data = new_others_data
        # 		tmp_prefix_candidate = tmp_prefix_candidate + "others_mod_"

        if prefix_to_data_name == None:
            _prefix_to_data_name = tmp_prefix_candidate
        else:
            _prefix_to_data_name = prefix_to_data_name

        # match prefix_to_data_name:
        # 	case None:
        # 		_prefix_to_data_name = tmp_prefix_candidate
        # 	case _:
        # 		_prefix_to_data_name = prefix_to_data_name

        return Voltammogram(
            self._data_name,
            _new_potential,
            _new_current,
            self._RE,
            _new_time,
            #self._conditions,
            _new_other_data
        )

        
        """mod_attr_dict = {
            "_data_name": self.data_name + _prefix_to_data_name,
            "_potential": _new_potential,
            "_current": _new_current,
            "_other_data": _new_other_data
        }

        return self.__make_modified_object(mod_attr_dict)"""

    @cmn.immutator
    def convert_potential_reference(
            self, 
            RE_before: ReferenceElectrode, 
            RE_after: ReferenceElectrode):
        """
        """
        RE_diff = RE_after-RE_before
        new_voltammogram = Voltammogram(
            _potential = self.potential-RE_diff,
            _current = self.current,
            _data_name = self.data_name+"_RE_corrected_"+str(RE_diff)+"V",
            _RE = RE_after,
            _others_data = self.others_data,
            _time = self.time,
            _condition = self.condition,
            _comment = self.comment+["RE corrected: {} -> {}".format(RE_before, RE_after)],
            _original_file_path = self._original_file_path
            #_conditions = self.conditions
        )
        return new_voltammogram
    
    @cmn.immutator
    def IR_correction(self, resistance: Resistance):
        new_voltammogram = Voltammogram(
            _potential = self.potential - self.current.iR_correction(resistance),
            _current = self.current,
            _data_name = self.data_name + "_iR_corrected_"+str(resistance)+"Ohm",
            _RE = self._RE,
            _others_data = self.others_data,
            _time = self.time,
            _comment = self.comment,
            _condition = self.condition,
            _original_file_path= self._original_file_path
        )
        return new_voltammogram
    
    
    def plot(self, fig: Optional[plt.Figure]=None, ax: Optional[plt.Axes]=None, **args)->tuple[plt.Figure, plt.Axes]:
        (_fig, _ax) = super().plot(fig, ax)
        if (ax == None):
            _ax.set_xlabel("Potential")
            _ax.set_ylabel("Current")

        #_ax.plot(self.potential, self.current, **args)

        return (_fig, _ax)

    
@dataclass(frozen=True, repr=False)
class EIS(do.DataSeriese[ResistanceArray, ResistanceArray]):
    _real_Z: ResistanceArray
    """in Ohm"""
    @property
    def real_Z(self):
        return self._real_Z

    _imaginary_Z : ResistanceArray
    """in Ohm"""
    @property
    def imaginary_Z(self):
        return self._imaginary_Z
    
    _frequency: FrequencyArray
    @property
    def frequency(self):
        return self._frequency
    
    @property
    def abs_Z(self):
        return ResistanceArray(np.sqrt(
            self._real_Z.float_array()**2 +
            self._imaginary_Z.float_array()**2
        ))
    
    @property
    def phase(self):
        return np.arctan2(
            self._imaginary_Z.float_array(),
            self._real_Z.float_array()
        )
    
    @property
    def impedance(self):
        return ImpedanceArray(
            self.real_Z.float_array() + 1j*self.imaginary_Z.float_array()
        )
    
    """_phase: cmn.ValueObjectArray
    @property
    def phase(self):
        return self._phase"""

    _other_data: pd.DataFrame
    @property
    def other_data(self)->pd.DataFrame:
        return self._other_data
    
    _applied_potential: Optional[Potential] = None
    @property
    def applied_potential(self)->Optional[Potential]:
        return self._applied_potential
    
    @property
    def x(self):
        return self._real_Z
    
    @property
    def y(self):
        return self._imaginary_Z

    def to_data_frame(self) -> pd.DataFrame:
        n_data = len(self._frequency.float_array())
        n_total = max(n_data, len(self._comment), len(self._condition))

        def pad_str(lst: list[str]) -> list:
            return lst + [pd.NA] * (n_total - len(lst))

        def pad_float(arr) -> np.ndarray:
            tail = np.full(n_total - len(arr), np.nan)
            return np.concatenate([arr, tail])

        base = pd.DataFrame(
            np.stack([
                pad_float(self._frequency.float_array()),
                pad_float(self._real_Z.float_array()),
                pad_float(self._imaginary_Z.float_array()),
            ], 1),
            columns=["frequency", "real Z", "imaginary Z"],
        )
        if not self._other_data.empty:
            other = self._other_data.reindex(range(n_total))
            base = base.join(other)
        base["comment"]   = pd.array(pad_str(self._comment),   dtype="string")
        base["condition"] = pd.array(pad_str(self._condition), dtype="string")
        return base
    
    @classmethod
    def from_data_frame(
        cls, 
        df: pd.DataFrame, 
        comment: list[str] = [], 
        condition: list[str] = [], 
        original_file_path: str = ""
        ) -> Self:
        return cls(
            _comment = df["comment"].dropna().tolist()+comment,
            _condition = df["condition"].dropna().tolist()+condition,
            _original_file_path = original_file_path,
            _data_name = f"Generated from dataframe({cmn.extract_filename(original_file_path)})",
            _real_Z = ResistanceArray(df["real Z"].dropna()),
            _imaginary_Z = ResistanceArray(df["imaginary Z"].dropna()),
            _frequency = FrequencyArray(df["frequency"].dropna().to_numpy()),
            _other_data = pd.DataFrame(
                df.drop(columns="frequency")\
                .drop(columns= "real Z")\
                .drop(columns="imaginary Z")),
        )

    def plot(self, fig: Optional[plt.Figure]=None, ax: Optional[plt.Axes]=None, **args)->tuple[plt.Figure, plt.Axes]:
        """
        Nyquest plot
        """
        (_fig, _ax) = super().plot(fig, ax)
        if (ax == None):
            _ax.set_xlabel("Real Z [Ohm]")
            _ax.set_ylabel("-Imaginary Z [Ohm]")
            _ax.axvline(0, linewidth = 1, color = "#303030")
            _ax.axhline(0, linewidth = 1, color = "#303030")
        #_ax.plot(self._real_Z, self._imaginary_Z)

        if (self.get_resistance() is not None):
            _ax.axvline(self.get_resistance().value, -0.2, 0.2, linestyle = "dotted")
        

        return (_fig, _ax)


    def get_resistance(self)->Optional[Resistance]:
        # 虚部の符号が反転する点(実軸との交点)での実部の最小値を返す。
        # np.delete は QArray を素の ndarray に降格させるため、素の配列で計算する。
        imaginary_raw = self.imaginary_Z.float_array()
        higher = np.delete(imaginary_raw, 0)
        lower = np.delete(imaginary_raw, -1)
        product = higher * lower
        cross_indexes = np.where(product < 0.0)[0]+1

        if len(cross_indexes) > 0:
            return self._real_Z[cross_indexes].min()
        else:
            return None


@dataclass(frozen=True, repr=False)
class ChronoAmperogram(do.DataSeriese[cmn.TimeArray, CurrentArray]):
    
    _time : cmn.TimeArray
    @property
    def time(self):
        return self._time
    
    _potential: PotentialArray
    @property
    def potential(self):
        return self._potential
    
    _current: CurrentArray
    @property
    def current(self):
        return self._current
    
    _other_data: pd.DataFrame
    @property
    def other_data(self):
        return self._other_data
    
    @property
    def x(self):
        return self._time
    
    @property
    def y(self):
        return self._current
    
    def to_data_frame(self) -> pd.DataFrame:
        return pd.DataFrame(
            np.stack([
                self._time.float_array(),
                self._current.float_array(),
                self._potential.float_array()
            ], 1),
            columns = [
                "time",
                "current",
                "potential"
            ]
        ).join(
            self.other_data
        )
    
    @classmethod
    def from_data_frame(
        cls, 
        df: pd.DataFrame, 
        comment: list[str] = [], 
        condition: list[str] = [], 
        original_file_path: str = "",
        ) -> Self:
        
        return ChronoAmperogram(
            _comment = comment,
            _condition = condition,
            _original_file_path = original_file_path,
            _data_name = f"Generated from dataframe({cmn.extract_filename(original_file_path)})",
            _time = cmn.TimeArray(df["time"]),
            _potential = PotentialArray(df["potential"]),
            _current = CurrentArray(df["current"]),
            _other_data = df.drop(columns=['time', 'potential', 'current'])
        )
    
    @cmn.immutator
    def IR_correction(self, resistance: Resistance):
        new_ammperogram = ChronoAmperogram(
            _potential = self.potential - self.current.iR_correction(resistance),
            _current = self.current,
            _data_name = self.data_name + "_iR_corrected_"+str(resistance)+"Ohm",
            _other_data = self.other_data,
            _time = self.time,
            _comment = self.comment,
            _condition = self.condition,
            _original_file_path= self._original_file_path
        )
        return new_ammperogram
    
    
"""
To do
to_data_frame関連の引数を修正
"""
@dataclass(frozen=True, repr=False)
class ChronoPotentiogram(do.DataSeriese[cmn.TimeArray, PotentialArray]):
    
    _time : cmn.TimeArray
    @property
    def time(self):
        return self._time
    
    _potential: PotentialArray
    @property
    def potential(self):
        return self._potential
    
    """_potential_CE: PotentialArray
    @property
    def potential_CE(self):
        return self._potential_CE"""
    
    
    _current: CurrentArray
    @property
    def current(self):
        return self._current
    
    _other_data: pd.DataFrame
    @property
    def other_data(self):
        return self._other_data
    
    @property
    def x(self):
        return self._time
    
    @property
    def y(self):
        return self._potential
    
    def to_data_frame(self) -> pd.DataFrame:
        return pd.DataFrame(
            np.stack([
                self._time.float_array(),
                self._current.float_array(),
                self._potential.float_array()
            ], 1),
            columns = [
                "time",
                "current",
                "potential"
            ]
        ).join(
            self.other_data
        )
    
    @classmethod
    def from_data_frame(
        cls, 
        df: pd.DataFrame, 
        comment: list[str] = [], 
        condition: list[str] = [], 
        original_file_path: str = "",
        ) -> Self:
        
        return ChronoPotentiogram(
            _comment = comment,
            _condition = condition,
            _original_file_path = original_file_path,
            _data_name = f"Generated from dataframe({cmn.extract_filename(original_file_path)})",
            _time = cmn.TimeArray(df["time"].values),
            _potential = PotentialArray(df["potential"].values),
            _current = CurrentArray(df["current"].values)
        )
    
    @cmn.immutator
    def IR_correction(self, resistance: Resistance):
        new_potentiogram = ChronoPotentiogram(
            _potential = self.potential - self.current.iR_correction(resistance),
            _current = self.current,
            _data_name = self.data_name + "_iR_corrected_"+str(resistance)+"Ohm",
            _other_data = self.other_data,
            _time = self.time,
            _comment = self.comment,
            _condition = self.condition,
            _original_file_path= self._original_file_path
        )
        return new_potentiogram
    
    @cmn.immutator
    def convert_potential_reference(
            self, 
            RE_before: ReferenceElectrode, 
            RE_after: ReferenceElectrode):
        """
        """
        RE_diff = RE_after-RE_before
        new_potentiogram = ChronoPotentiogram(
            _potential = self.potential-RE_diff,
            _current = self.current,
            _data_name = self.data_name + "_iR_corrected_"+str(RE_diff)+"V",
            _other_data = self.other_data,
            _time = self.time,
            _comment = self.comment,
            _condition = self.condition,
            _original_file_path= self._original_file_path
        )
        return new_potentiogram
    
    @cmn.immutator
    def modify(
        self,
        new_potential: Optional[Potential] = None,
        new_current: Optional[Current] = None,
        new_time: Optional[cmn.Time] = None,
        new_others_data: Optional[np.ndarray] = None,
        prefix_to_data_name: Optional[str] = None
    ):
        tmp_prefix_candidate: str = "_"

        if new_potential is None:
            _new_potential = self._potential
        else:
            _new_potential = new_potential
            tmp_prefix_candidate = tmp_prefix_candidate + "potential_mod_"
            
        
        if new_current is None:
            _new_current = self.current
        else:
            _new_current = new_current
            tmp_prefix_candidate = tmp_prefix_candidate + "current_mod_"
        

            
        if new_time is None:
            _new_time = self.time
        else:
            _new_time = new_time
        

        if new_others_data is None:
            _new_other_data = self.other_data
        else:
            _new_other_data = new_others_data
            tmp_prefix_candidate = tmp_prefix_candidate + "others_mod_"


        if prefix_to_data_name is None:
            _prefix_to_data_name = tmp_prefix_candidate
        else:
            _prefix_to_data_name = prefix_to_data_name



        return ChronoPotentiogram(
            _comment = self._comment,
            _condition = self._condition,
            _original_file_path = self._original_file_path,
            _data_name = _prefix_to_data_name + self._data_name,
            _time = _new_time,
            _potential = _new_potential,
            _current = _new_current,
            _other_data = _new_other_data
        )




#---------------------------------------------------------------
#functions
#---------------------------------------------------------------

def convert_potential_reference(
        voltammogram: Voltammogram, 
        RE_before: ReferenceElectrode, 
        RE_after: ReferenceElectrode
        )->Voltammogram:
    
    potential_diff = RE_before - RE_after


    return Voltammogram(
        
        _comment = voltammogram.comment + ["RE converted: {} -> {}".format(RE_before, RE_after)],
        _condition = voltammogram.condition,
        _original_file_path = voltammogram.original_file_path,
        _data_name = voltammogram.data_name,
        _RE = RE_after,
        _others_data = voltammogram.others_data,
        _potential = voltammogram.potential + potential_diff,
        _current = voltammogram.current,
        _time = voltammogram.time
    )


"""def mupltiply_current(
        voltammogram: Voltammogram,
        multiplied_value: float
)->Voltammogram:
    pass"""