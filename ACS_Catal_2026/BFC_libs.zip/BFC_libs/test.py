#%%
import originpro as op


#---------------------------------------------------------------------------
# AttributeError                            Traceback (most recent call last)
# File c:\Users\(repository directory))\test.py:2
#       1 #%%
# ----> 2 import originpro as op

# File c:\Users\(User folder)\AppData\Local\Programs\Python\Python312\Lib\site-packages\originpro\__init__.py:9
#       7 from os.path import dirname, basename, isfile, join
#       8 import glob
# ----> 9 from .config import *
#      10 from .project import *
#      11 from .worksheet import *

# File c:\Users\(User folder)\AppData\Local\Programs\Python\Python312\Lib\site-packages\originpro\config.py:70
#      67 try:
#      68     import numpy as np
#      69     npdtype_to_orgdtype = {
# ---> 70         np.float64: po.DF_DOUBLE,
#      71         np.float32: po.DF_FLOAT,
#      72         np.int16: po.DF_SHORT,
#      73         np.int32: po.DF_LONG,
#      74         np.int8: po.DF_CHAR,
#      75         np.uint8: po.DF_BYTE,
#      76         np.uint16: po.DF_USHORT,
#      77         np.uint32: po.DF_ULONG,
# ...
#      79     }
#      80     npdtype_to_orgdtype[np.int64] = po.DF_LONG
#      81     orgdtype_to_npdtype = {v: k for k, v in npdtype_to_orgdtype.items()}

# AttributeError: module 'PyOrigin' has no attribute 'DF_DOUBLE'
#%%
import originpro as op


# Ensures that the Origin instance gets shut down properly.
import sys
def origin_shutdown_exception_hook(exctype, value, traceback):
    op.exit()
    sys.__excepthook__(exctype, value, traceback)
if op and op.oext:
    sys.excepthook = origin_shutdown_exception_hook


# Set Origin instance visibility.
if op.oext:
    op.set_show(True)


# YOUR CODE HERE
#%%
# Exit running instance of Origin.
if op.oext:
    op.exit()

#%%
import originpro as op

a = op.config.APP()

a.LT_set_var("@VIS", 100)

b = a.GetRootFolder()

aa = op.config.APP()
#%%
import origin_pro_support as ops
import os


a = ops.OriginInstance(os.getcwd() + "\\test_2.opju")
b = a.get_root_dir()
for c in a.get_API.GetWorksheetPages():
    print(c.Name)

#%%
import originpro as op
import numpy as np
import pandas as pd


# Very useful, especially during development, when you are
# liable to have a few uncaught exceptions.
# Ensures that the Origin instance gets shut down properly.
# Note: only applicable to external Python.
import sys
def origin_shutdown_exception_hook(exctype, value, traceback):
    '''Ensures Origin gets shut down if an uncaught exception'''
    op.exit()
    sys.__excepthook__(exctype, value, traceback)
if op and op.oext:
    sys.excepthook = origin_shutdown_exception_hook


# Set Origin instance visibility.
# Important for only external Python.
# Should not be used with embedded Python. 
if op.oext:
    op.set_show(True)

op.get_page
# Example of opening a project and reading data.

# We'll open the Tutorial Data.opju project that ships with Origin.
src_opju = op.path('e')+ r'Samples\Tutorial Data.opju'
op.open(file = src_opju, readonly = True)

# Simple syntax to find a worksheet.
src_wks = op.find_sheet('w', 'Book1A')

# Pull first column data into a list and dump to screen.
lst = src_wks.to_list(0)
print(*lst, sep = ", ")

# Pull entire worksheet into a pandas DataFrame and partially dump to screen.
# Column long name will be columns name.
df = src_wks.to_df()
print(df.head())


# Start a new project which closes the previous one.
op.new()


#Examples of writing data to a project and saving it.

# We'll reuse the data objects we previously created.

# Simple syntax to create a new workbook with one sheet
dest_wks = op.new_sheet('w')

# Insert list data into columns 1
dest_wks.from_list(0, lst)

# Add another sheet top above workbook and add the DataFrame data.
# DataFrame column names with be Origin column Long Names.
dest_wks.get_book().add_sheet().from_df(df)

# Save the opju to your UFF.
op.save(op.path('u')+ 'Ext Python Example 1.opju')

#%%
# Exit running instance of Origin.
# Required for external Python but don't use with embedded Python.
if op.oext:
    op.exit()

#%%
#import OriginExt as oext
import OriginExt._OriginExt as po_API


#%%
import originpro as op

a = op.root_folder()